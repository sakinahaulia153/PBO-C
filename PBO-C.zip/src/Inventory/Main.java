package Inventory;


public class Main {
    public static void main(String[] args) {
        List produk = new List();
        produk.menu();
        produk.getnilaidata();
    }
}
